# uxfyp

This project is for my final year project.

I am learning how to build a website through html, css and js. Any suggestions / help would be appreciated! 

email me at 116485502@umail.ucc.ie for any questions.
